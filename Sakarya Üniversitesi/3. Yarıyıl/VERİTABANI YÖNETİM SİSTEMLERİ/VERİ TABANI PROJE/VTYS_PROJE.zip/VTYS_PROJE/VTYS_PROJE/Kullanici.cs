﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace VTYS_PROJE
{
    public partial class Kullanici : Form
    {
        public Kullanici()
        {
            InitializeComponent();
        }

        private string connstring = ("server=localHost;port=5432;Database=film;user ID=postgres;password=1");
        private NpgsqlConnection conn3;
        private string sql;
        private NpgsqlCommand cmd;
        private DataTable dt;
        private void Kullanici_Load(object sender, EventArgs e)
        {
            conn3 = new NpgsqlConnection(connstring);
        }

        private void kullaniciFilmAraButon_Click(object sender, EventArgs e)
        {
            try
            {
                conn3.Open();
                sql = @"SELECT*from film_ara(:filmad)";
                cmd = new NpgsqlCommand(sql, conn3);

                cmd.Parameters.AddWithValue("filmad", textBox1.Text);

                int result = (int)cmd.ExecuteScalar();

                conn3.Close();

                if (result == 1)
                {
                    this.Hide();
                    Film FilmForm = new Film();
                    FilmForm.label1.Text = textBox1.Text;
                    FilmForm.Show();
                }
                else
                {
                    MessageBox.Show("Film Bulunamadı!");
                    return;
                }
            }
            catch (Exception ex)
            {
                conn3.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
