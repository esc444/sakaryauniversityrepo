﻿namespace VTYS_PROJE
{
    partial class Film
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.filmVizyonTarihi = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.filmKonu = new System.Windows.Forms.Label();
            this.filmOylamaDeger = new System.Windows.Forms.Label();
            this.filmTur = new System.Windows.Forms.Label();
            this.oylamaYap = new System.Windows.Forms.Label();
            this.yorumlariGor = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtKONU = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "film ad";
            // 
            // filmVizyonTarihi
            // 
            this.filmVizyonTarihi.AutoSize = true;
            this.filmVizyonTarihi.Location = new System.Drawing.Point(80, 100);
            this.filmVizyonTarihi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.filmVizyonTarihi.Name = "filmVizyonTarihi";
            this.filmVizyonTarihi.Size = new System.Drawing.Size(73, 13);
            this.filmVizyonTarihi.TabIndex = 5;
            this.filmVizyonTarihi.Text = "Vizyon Tarihi: ";
            this.filmVizyonTarihi.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "label2";
            this.label2.Visible = false;
            // 
            // filmKonu
            // 
            this.filmKonu.AutoSize = true;
            this.filmKonu.Location = new System.Drawing.Point(82, 171);
            this.filmKonu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.filmKonu.Name = "filmKonu";
            this.filmKonu.Size = new System.Drawing.Size(38, 13);
            this.filmKonu.TabIndex = 7;
            this.filmKonu.Text = "Konu: ";
            this.filmKonu.Visible = false;
            this.filmKonu.Click += new System.EventHandler(this.filmKonu_Click);
            // 
            // filmOylamaDeger
            // 
            this.filmOylamaDeger.AutoSize = true;
            this.filmOylamaDeger.Location = new System.Drawing.Point(80, 63);
            this.filmOylamaDeger.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.filmOylamaDeger.Name = "filmOylamaDeger";
            this.filmOylamaDeger.Size = new System.Drawing.Size(13, 13);
            this.filmOylamaDeger.TabIndex = 8;
            this.filmOylamaDeger.Text = "0";
            this.filmOylamaDeger.Click += new System.EventHandler(this.filmOylamaDeger_Click);
            // 
            // filmTur
            // 
            this.filmTur.AutoSize = true;
            this.filmTur.Location = new System.Drawing.Point(82, 276);
            this.filmTur.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.filmTur.Name = "filmTur";
            this.filmTur.Size = new System.Drawing.Size(26, 13);
            this.filmTur.TabIndex = 10;
            this.filmTur.Text = "Tür:";
            this.filmTur.Visible = false;
            // 
            // oylamaYap
            // 
            this.oylamaYap.AutoSize = true;
            this.oylamaYap.Location = new System.Drawing.Point(374, 63);
            this.oylamaYap.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.oylamaYap.Name = "oylamaYap";
            this.oylamaYap.Size = new System.Drawing.Size(64, 13);
            this.oylamaYap.TabIndex = 11;
            this.oylamaYap.Text = "Oylama Yap";
            this.oylamaYap.Visible = false;
            // 
            // yorumlariGor
            // 
            this.yorumlariGor.AutoSize = true;
            this.yorumlariGor.Location = new System.Drawing.Point(374, 100);
            this.yorumlariGor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.yorumlariGor.Name = "yorumlariGor";
            this.yorumlariGor.Size = new System.Drawing.Size(70, 13);
            this.yorumlariGor.TabIndex = 12;
            this.yorumlariGor.Text = "Yorumları Gor";
            this.yorumlariGor.Visible = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(33, 302);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(447, 54);
            this.dataGridView2.TabIndex = 16;
            this.dataGridView2.Visible = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtKONU
            // 
            this.txtKONU.AcceptsReturn = true;
            this.txtKONU.Location = new System.Drawing.Point(164, 171);
            this.txtKONU.Multiline = true;
            this.txtKONU.Name = "txtKONU";
            this.txtKONU.ReadOnly = true;
            this.txtKONU.Size = new System.Drawing.Size(274, 85);
            this.txtKONU.TabIndex = 18;
            this.txtKONU.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(161, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(164, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "adlı film veritabanında mevcutturr.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(98, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "yorum bulunmaktadır.";
            // 
            // Film
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 366);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtKONU);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.yorumlariGor);
            this.Controls.Add(this.oylamaYap);
            this.Controls.Add(this.filmTur);
            this.Controls.Add(this.filmOylamaDeger);
            this.Controls.Add(this.filmKonu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.filmVizyonTarihi);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Film";
            this.Text = "Film";
            this.Load += new System.EventHandler(this.Film_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label filmVizyonTarihi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label filmKonu;
        private System.Windows.Forms.Label filmOylamaDeger;
        private System.Windows.Forms.Label filmTur;
        private System.Windows.Forms.Label oylamaYap;
        private System.Windows.Forms.Label yorumlariGor;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        public System.Windows.Forms.TextBox txtKONU;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}