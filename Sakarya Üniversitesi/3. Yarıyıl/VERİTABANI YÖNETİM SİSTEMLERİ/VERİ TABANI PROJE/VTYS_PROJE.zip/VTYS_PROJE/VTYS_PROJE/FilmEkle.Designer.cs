﻿namespace VTYS_PROJE
{
    partial class FilmEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.filmIDLabel = new System.Windows.Forms.Label();
            this.filmAdLabel = new System.Windows.Forms.Label();
            this.VizyonTarihLabel = new System.Windows.Forms.Label();
            this.KonuLabel = new System.Windows.Forms.Label();
            this.filmID = new System.Windows.Forms.TextBox();
            this.FilmAd = new System.Windows.Forms.TextBox();
            this.VizyonTarih = new System.Windows.Forms.TextBox();
            this.Konu = new System.Windows.Forms.TextBox();
            this.filmTur = new System.Windows.Forms.Label();
            this.Tur = new System.Windows.Forms.TextBox();
            this.filmEkleButon = new System.Windows.Forms.Button();
            this.TurEkleButon = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // filmIDLabel
            // 
            this.filmIDLabel.AutoSize = true;
            this.filmIDLabel.Location = new System.Drawing.Point(56, 48);
            this.filmIDLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.filmIDLabel.Name = "filmIDLabel";
            this.filmIDLabel.Size = new System.Drawing.Size(42, 13);
            this.filmIDLabel.TabIndex = 0;
            this.filmIDLabel.Text = "Film ID:";
            // 
            // filmAdLabel
            // 
            this.filmAdLabel.AutoSize = true;
            this.filmAdLabel.Location = new System.Drawing.Point(56, 89);
            this.filmAdLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.filmAdLabel.Name = "filmAdLabel";
            this.filmAdLabel.Size = new System.Drawing.Size(44, 13);
            this.filmAdLabel.TabIndex = 1;
            this.filmAdLabel.Text = "Film Ad:";
            // 
            // VizyonTarihLabel
            // 
            this.VizyonTarihLabel.AutoSize = true;
            this.VizyonTarihLabel.Location = new System.Drawing.Point(56, 133);
            this.VizyonTarihLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.VizyonTarihLabel.Name = "VizyonTarihLabel";
            this.VizyonTarihLabel.Size = new System.Drawing.Size(70, 13);
            this.VizyonTarihLabel.TabIndex = 2;
            this.VizyonTarihLabel.Text = "Vizyon Tarihi:";
            // 
            // KonuLabel
            // 
            this.KonuLabel.AutoSize = true;
            this.KonuLabel.Location = new System.Drawing.Point(56, 173);
            this.KonuLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.KonuLabel.Name = "KonuLabel";
            this.KonuLabel.Size = new System.Drawing.Size(35, 13);
            this.KonuLabel.TabIndex = 3;
            this.KonuLabel.Text = "Konu:";
            // 
            // filmID
            // 
            this.filmID.Location = new System.Drawing.Point(160, 43);
            this.filmID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.filmID.Name = "filmID";
            this.filmID.Size = new System.Drawing.Size(76, 20);
            this.filmID.TabIndex = 4;
            // 
            // FilmAd
            // 
            this.FilmAd.Location = new System.Drawing.Point(160, 89);
            this.FilmAd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FilmAd.Name = "FilmAd";
            this.FilmAd.Size = new System.Drawing.Size(76, 20);
            this.FilmAd.TabIndex = 5;
            // 
            // VizyonTarih
            // 
            this.VizyonTarih.Location = new System.Drawing.Point(160, 129);
            this.VizyonTarih.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.VizyonTarih.Name = "VizyonTarih";
            this.VizyonTarih.Size = new System.Drawing.Size(76, 20);
            this.VizyonTarih.TabIndex = 6;
            // 
            // Konu
            // 
            this.Konu.Location = new System.Drawing.Point(160, 169);
            this.Konu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Konu.Name = "Konu";
            this.Konu.Size = new System.Drawing.Size(76, 20);
            this.Konu.TabIndex = 7;
            // 
            // filmTur
            // 
            this.filmTur.AutoSize = true;
            this.filmTur.Location = new System.Drawing.Point(56, 283);
            this.filmTur.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.filmTur.Name = "filmTur";
            this.filmTur.Size = new System.Drawing.Size(26, 13);
            this.filmTur.TabIndex = 8;
            this.filmTur.Text = "Tür:";
            // 
            // Tur
            // 
            this.Tur.Location = new System.Drawing.Point(160, 279);
            this.Tur.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Tur.Name = "Tur";
            this.Tur.Size = new System.Drawing.Size(76, 20);
            this.Tur.TabIndex = 9;
            // 
            // filmEkleButon
            // 
            this.filmEkleButon.Location = new System.Drawing.Point(166, 207);
            this.filmEkleButon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.filmEkleButon.Name = "filmEkleButon";
            this.filmEkleButon.Size = new System.Drawing.Size(68, 40);
            this.filmEkleButon.TabIndex = 10;
            this.filmEkleButon.Text = "Ekle";
            this.filmEkleButon.UseVisualStyleBackColor = true;
            this.filmEkleButon.Click += new System.EventHandler(this.button1_Click);
            // 
            // TurEkleButon
            // 
            this.TurEkleButon.Location = new System.Drawing.Point(166, 317);
            this.TurEkleButon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TurEkleButon.Name = "TurEkleButon";
            this.TurEkleButon.Size = new System.Drawing.Size(68, 40);
            this.TurEkleButon.TabIndex = 11;
            this.TurEkleButon.Text = "Ekle";
            this.TurEkleButon.UseVisualStyleBackColor = true;
            this.TurEkleButon.Click += new System.EventHandler(this.TurEkleButon_Click);
            // 
            // FilmEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(305, 382);
            this.Controls.Add(this.TurEkleButon);
            this.Controls.Add(this.filmEkleButon);
            this.Controls.Add(this.Tur);
            this.Controls.Add(this.filmTur);
            this.Controls.Add(this.Konu);
            this.Controls.Add(this.VizyonTarih);
            this.Controls.Add(this.FilmAd);
            this.Controls.Add(this.filmID);
            this.Controls.Add(this.KonuLabel);
            this.Controls.Add(this.VizyonTarihLabel);
            this.Controls.Add(this.filmAdLabel);
            this.Controls.Add(this.filmIDLabel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FilmEkle";
            this.Text = "Film Ekle";
            this.Load += new System.EventHandler(this.FilmEkle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label filmIDLabel;
        private System.Windows.Forms.Label filmAdLabel;
        private System.Windows.Forms.Label VizyonTarihLabel;
        private System.Windows.Forms.Label KonuLabel;
        private System.Windows.Forms.TextBox filmID;
        private System.Windows.Forms.TextBox FilmAd;
        private System.Windows.Forms.TextBox VizyonTarih;
        private System.Windows.Forms.TextBox Konu;
        private System.Windows.Forms.Label filmTur;
        private System.Windows.Forms.TextBox Tur;
        private System.Windows.Forms.Button filmEkleButon;
        private System.Windows.Forms.Button TurEkleButon;
    }
}