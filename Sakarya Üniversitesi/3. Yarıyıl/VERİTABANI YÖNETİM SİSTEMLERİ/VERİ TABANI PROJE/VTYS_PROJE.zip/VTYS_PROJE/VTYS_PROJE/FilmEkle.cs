﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace VTYS_PROJE
{
    public partial class FilmEkle : Form
    {
        public FilmEkle()
        {
            InitializeComponent();
        }

        private string connstring = ("server=localHost;port=5432;Database=film;user ID=postgres;password=1");
        private NpgsqlConnection conn5;
        private string sql;
        private NpgsqlCommand cmd;
        private DataTable dt;


        private void FilmEkle_Load(object sender, EventArgs e)
        {
            conn5 = new NpgsqlConnection(connstring);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn5.Open();
                sql = @"SELECT*from film_ekle(:filmad, :filmid)";
                cmd = new NpgsqlCommand(sql, conn5);

                cmd.Parameters.AddWithValue("filmad", FilmAd.Text);
                cmd.Parameters.AddWithValue("filmid", Convert.ToInt32(filmID.Text));
                //cmd.Parameters.AddWithValue("filmKonu", Konu.Text);
                //cmd.Parameters.AddWithValue("vizyonTarihi", VizyonTarih.Text);
                int result = (int)cmd.ExecuteScalar();

                conn5.Close();

                if (result == 1)
                {
                    this.Hide();
                    //Kullanici kullaniciForm = new Kullanici();
                    ////kullaniciForm.label1.Text = kullaniciGirilenAd.Text;
                    //kullaniciForm.Show();
                }
                else
                {
                    MessageBox.Show("Hata!");
                    return;
                }

            }

            catch (Exception ex)
            {
                conn5.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void TurEkleButon_Click(object sender, EventArgs e)
        {
            try
            {
                conn5.Open();
            sql = @"SELECT*from film_ekle(:filmAd, :filmID";
            cmd = new NpgsqlCommand(sql, conn5);
            }

            catch (Exception ex)
            {
                conn5.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
